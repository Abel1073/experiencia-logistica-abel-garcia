# Experiencia Profesional

## Unión Temporal Nueva Logística / Jefe de Bodega – DIAN (2023-2024)

- Montaje del sistema de estantería tipo Rack
- Clasificación y gestión de mercancías bajo cadena de custodia
- Coordinación operativa regional bajo ANS

## Agropaisa S.A.S / Jefe de CEDI (2022–2023)

- Sincronización de KPIs operativos (+20%)
- Implementación de sistema de almacenamiento
- Optimización de tiempos de operación

## Jamar S.A / Coordinador Logístico (2013–2019)

- KPI de entregas perfectas mejorado en +15%
- Proyecto de RFID que redujo errores en +98%

## Otras experiencias:

- Docente e instructor en formación técnica logística (SENA, CEC)
- Coordinador logístico en planta de gases (Linde / OLC)
