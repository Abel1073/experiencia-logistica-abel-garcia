# Certificaciones y Educación

## Educación Formal

- Especialista en Gerencia Logística – U. Sergio Arboleda (2023)
- Ingeniero Industrial – U. Antonio Nariño (2014)
- Tecnólogo en Gestión Logística – SENA (2012)
- Tecnólogo en Análisis y Desarrollo de Software – En curso (2025)

## Certificación Destacada

- Talento Excepcional – Premio Jamar S.A (2016)
- Diplomados en liderazgo, herramientas digitales y cadena de suministro
- Formación certificada en logística, ISO, SST y manejo de alimentos
