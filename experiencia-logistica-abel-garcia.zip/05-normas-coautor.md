# Normas Sectoriales Coautoradas

Abel García Manjarrés es coautor de las siguientes Normas Sectoriales de Competencias Laborales del SENA:

- NSCL: 210101074
- NSCL: 210101075
- NSCL: 210101081
- NSCL: 210101082
- NSCL: 210101083
- NSCL: 210101086

📎 Ver en línea: [https://competencias.sena.edu.co/](https://competencias.sena.edu.co/)
