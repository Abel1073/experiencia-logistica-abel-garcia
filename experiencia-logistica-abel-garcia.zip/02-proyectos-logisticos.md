# Proyectos Logísticos Relevantes

- 📦 **Estanterías tipo Rack:** Diseño y montaje en múltiples bodegas (DIAN, Agropaisa, Jamar)
- 📶 **Proyecto RFID:** Implementación de sistema de identificación para minimizar errores en despacho
- 📈 **KPIs logísticos:** Optimización y control en centros de distribución
- 📋 **Planeación de rutas:** Estudios de métodos y tiempos (Linde, El Paso - Drummond)
