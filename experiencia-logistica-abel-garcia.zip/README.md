# Portafolio Profesional – Abel García Manjarrés

Este repositorio presenta la experiencia, habilidades y logros en el campo de la logística del Ingeniero Industrial y Especialista en Gerencia Logística Abel García Manjarrés.

## 👨‍💼 Perfil Profesional

Profesional con más de 15 años de experiencia liderando operaciones logísticas, manejo de inventarios, diseño de procesos, optimización de bodegas, docencia técnica y consultoría. Coautor de normas del SENA y miembro activo del Comité Nacional de Expertos en Logística.

## 🧠 Áreas de especialización

- Planeación logística
- Gestión de bodegas y CEDI
- Mejora de procesos operativos
- Docencia técnica y capacitación
- Implementación de sistemas WMS y ERP

## 🌐 Enlaces de interés

- [LinkedIn](https://www.linkedin.com/in/abelgarciamanjarres)
- [Normas SENA Coautor](https://competencias.sena.edu.co/)

## 📄 Contenido del repositorio

- `01-experiencia-profesional.md`
- `02-proyectos-logisticos.md`
- `03-competencias-y-sistemas.md`
- `04-certificaciones.md`
- `05-normas-coautor.md`

---

*Desarrollado con el propósito de visibilizar la trayectoria profesional de Abel García Manjarrés en entornos digitales.*
