# Competencias Técnicas y Sistemas

## Competencias

- Optimización de procesos logísticos
- Planeación de rutas
- Gestión de inventarios
- Liderazgo de equipos operativos
- Mejora continua

## Sistemas y ERP

- SAP (90%)
- SEUS (90%)
- CITRIX (90%)
- EXCEL (70%)
- SIESA (70%)
- FRONT OFFICE (70%)
